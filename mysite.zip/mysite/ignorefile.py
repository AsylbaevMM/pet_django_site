SECRET_KEY = 'django-insecure-c8y0)h55=iu*_3^+v+2@!mtsrxli8hq0*=lohft*u)lx(d!1@#'
DATABASEPASS = 'pass135790'
EMAIL = 'mister.asylbaeff@gmail.com'
EMAILPASS = 'dvux tebr nxhz hyhl'

SOCIAL_AUTH_GITHUB_KEY = '93e659d1d57ef0c95e87'
SOCIAL_AUTH_GITHUB_SECRET = 'bc8472f3848e64c71215f5599d300f2fa4334647'
SOCIAL_AUTH_GOOGLE_OAUTH2_KEY = '206353074039-qapekiv5ca9i9krrtv7d889hs5mdknt8.apps.googleusercontent.com'
SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET = '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'


SECRET_KEY = 'django-insecure-c8y0)h55=iu*_3^+v+2@!mtsrxli8hq0*=lohft*u)lx(d!1@#'
DATABASEPASS = 'pass135790'
EMAIL = 'mister.asylbaeff@gmail.com'
EMAILPASS = 'dvux tebr nxhz hyhl'

GITHUB_KEY = '93e659d1d57ef0c95e87'
GITHUB_SECRET = 'bc8472f3848e64c71215f5599d300f2fa4334647'
GOOGLE_KEY = '206353074039-qapekiv5ca9i9krrtv7d889hs5mdknt8.apps.googleusercontent.com'
GOOGLE_SECRET = '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'